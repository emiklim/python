from setuptools import setup

setup(

    name="Paquete_Cliente",
    version="1.0",
    description="Paquete de Clientes",
    author="Emi Klim",
    author_email="ezk364@gmail.com",
    packages= ["Paquete_Cliente"]
)